## 1.0.0:
* Move attributes to 'packages-cookbook' to avoid Ohai attribute conflicts
* Clean up Travis.CI testing

## 0.5.0:

* Added support for Chef 12.1.0 multipackage feature
* Reduced deprecation warnings with SoloRunner
* Cleanup and expansion of testing code

## 0.4.0:

* Clean up Arrays handling (@paulmooring)

## 0.3.0:

* Support for packages hash with action to take (@jtimberman)

## 0.2.0:

* Allow custom package actions using 'packages_action' attribute. (@AMeng)

## 0.1.0:

* Initial release
