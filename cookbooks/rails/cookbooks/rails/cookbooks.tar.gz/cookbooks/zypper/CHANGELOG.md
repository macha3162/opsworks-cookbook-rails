# zypper CHANGELOG

## 0.4.0

- [tas50] - Add Whyrun support
- [bluca] - Add repository priority attribute

## 0.3.0

- [tas50] - Add issues_url, source_url, and chef_version to the metadata
- [tas50] - Add Chefspec matchers for the repo LWRP
- [tas50] - Add testing and metadata supports attribute for opensuseleap

## 0.2.1

- [gimler] - Use --non-interactive mode when running zypper refresh

## 0.2.0

- [jarosser06] - Added Key attribute to allow importing a gpg key for a new repo
- [jarosser06] - Renamed alias attribute to repo_name

## 0.1.0

- [jarosser06] - Initial release of zypper
