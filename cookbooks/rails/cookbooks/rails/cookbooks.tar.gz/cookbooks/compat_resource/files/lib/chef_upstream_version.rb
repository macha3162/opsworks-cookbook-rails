        module ChefCompat
          CHEF_UPSTREAM_VERSION="12.16.42" unless defined? CHEF_UPSTREAM_VERSION
        end
